using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Bartolabac_SportsStore.Views.Shared
{
    public class ProductSummaryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
